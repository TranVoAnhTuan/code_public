load ex5-2-6
N = [-1 -2 -3 4 -5];
v = lb; v(4) = ub(4);
d = sign(A*v-b);
A = [A -diag(d)]; w = [zeros(5,1);ones(2,1)];
lb = [lb; zeros(2,1)]; ub = [ub; inf*ones(2,1)];
B = [6 7];
[x,B,N] = rsmbdd(A,b,w,lb,ub,B,N)
w'*x
ub(6:7) = zeros(2,1); p(6:7) = zeros(2,1);
[x,B,N] = rsmbdd(A,b,p,lb,ub,B,N)
p'*x

