load ex5-2-6
B = [1 2];
N = [-3 4 -5];
[m,l] = size(A);
x = zeros(l,1);
x(3:5) = [0 5 0]';
[L,U] = lu(A(:,B));
x(B) = U\(L\(b-A(:,abs(N))*x(abs(N))))
u = L'\(U'\p(B));
c = p(abs(N))-A(:,abs(N))'*u
s = 1;
d = U\(L\(A(:,abs(N(s)))))
lambda = 2/3;
x(3) = x(3) + lambda;
x(B) = x(B) - lambda*d
B(1) = 3; N(1) = -1;
[L,U] = lu(A(:,B));
u = L'\(U'\p(B));
c = p(abs(N))-A(:,abs(N))'*u;
s = 2;
d = U\(L\(A(:,abs(N(s)))))
lambda = 4/7;
x(4) = x(4) - lambda;
x(B) = x(B) + lambda*d
B(2) = 4; N(2) = 2;
u = L'\(U'\p(B));
c = p(abs(N))-A(:,abs(N))'*u

