load ex5-2-1
B = [3 4 6];
[x_B,B] = rsm_new(A,b,p,B)

