load ex5-2-10
v = lb;
N = [-2 -3 -4];
v(1) = b(2) - A(2,2:4)*v(2:4)
d = sign(A(1,:)*v - b(1));
A = horzcat(A, [-d 0]');
lb(5) = 0; ub(5) = inf;
B = [1 5];
w = [zeros(4,1); 1];
[x,B,N] = rsmbdd(A,b,w,lb,ub,B,N)
ub(5) = 0; p(5) = 0;
[x,B,N] = rsmbdd(A,b,p,lb,ub,B,N)
F = [1]; f = length(F);
[L,U,P] = lu(A(:,F));
[k,i] = find(P(1:f,:));
i

