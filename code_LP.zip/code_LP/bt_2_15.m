load ex5-2-15
s = 2;
[L,U,P] = lu(A)
H = U\(L\(P*(a-A(:,s))));
s = 2;
d = U\(L\(P*b));
d = d-H*(d(s)/(1+H(s,1)))

