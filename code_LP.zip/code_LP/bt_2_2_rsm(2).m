load ex5-2-2
A_backup = A;
A = horzcat(A,eye(4));
[m,l] = size(A);
B = [(l-m)+1:l];
p_backup = p;
p = -p;
tmp = p'
tmp = horzcat(tmp,zeros(1,length(B)));
p = tmp';
[x_B,B] = rsm(A,b,p,B)

