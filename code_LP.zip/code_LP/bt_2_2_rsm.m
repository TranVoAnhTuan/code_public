load ex5-2-1
B = [3 4 6];
[x_B,B] = rsm(A,b,p,B)
z = p(B)' * x_B

