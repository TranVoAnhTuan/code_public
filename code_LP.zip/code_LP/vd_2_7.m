load ex5-2-6
B = [1 2]; N = [-3 4 -5];
[x,B,N] = rsmbdd(A,b,p,lb,ub,B,N)

