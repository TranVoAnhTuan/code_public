load ex3-4-1
p = [p; zeros(5,1)];
x = simplex([A -eye(5)],b,p);
p'*x

