load ex5-2-1
[m,l] = size(A);
B = [3 4 6];
N = setdiff(1:l,B);
[L,U] = lu(A(:,B));
x_B = U\(L\b)
u = L'\(U'\p(B));
c = p(N)-A(:,N)'*u
s = 2;
d = U\(L\A(:,N(s)))
r=1; swap = B(r);
B(r) = N(s); N(s) = swap;
[L,U] = lu(A(:,B));
x_B = U\(L\b)
u = L'\(U'\p(B));
c = p(N)-A(:,N)'*u
s = 1; d = U\(L\A(:,N(s)))
r = 1; swap = B(r);
B(r) = N(s); N(s) = swap;
[L,U] = lu(A(:,B));
x_B = U\(L\b)
u = L'\(U'\p(B));
c = p(N)-A(:,N)'*u



