load ex5-2-12
x = simplex(A,b,p,lb,ub)

