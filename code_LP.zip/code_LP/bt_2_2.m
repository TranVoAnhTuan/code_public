load ex5-2-2
A_backup = A;
A = horzcat(A,eye(4));
[m,l] = size(A);
B = [(l-m)+1:l];
N = setdiff(1:l,B);
p_backup = p;
p = -p;
tmp = p';
tmp = horzcat(tmp,zeros(1,length(B)));
p = tmp';
[L,U] = lu(A(:,B));
x_B = U\(L\b)
u = L'\(U'\p(B));
c = p(N)-A(:,N)'*u
s = 2;
d = U\(L\A(:,N(s)))
x_B./d
r = 2;
swap = B(r);
B(r) = N(s);
N(s) = swap;
[L,U] = lu(A(:,B));
x_B = U\(L\b)
u = L'\(U'\p(B));
c = p(N)-A(:,N)'*u
s = 1;
d = U\(L\A(:,N(s)))
x_B./d
r = 1;
swap = B(r);
B(r) = N(s);
N(s) = swap;
[L,U] = lu(A(:,B));
x_B = U\(L\b)
u = L'\(U'\p(B));
c = p(N)-A(:,N)'*u
s = 3;
d = U\(L\A(:,N(s)))
r = 1;
swap = B(r);
B(r) = N(s);
N(s) = swap;
[L,U] = lu(A(:,B));
x_B = U\(L\b)
u = L'\(U'\p(B));
c = p(N)-A(:,N)'*u

