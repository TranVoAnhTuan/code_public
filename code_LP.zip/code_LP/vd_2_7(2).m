load ex5-2-6
[m,l] = size(A);
A = [A zeros(m,l); eye(l) eye(l)];
b = [b; ub]; p = [p; zeros(l,1)];
B = [1 2 4 6 7 8 10];
[x_B,B] = rsm(A,b,p,B)
x = zeros(2*l,1); x(B) = x_B

