load ex3-6-5
A = [A [-eye(2); zeros(1,2)]];
p = [p; zeros(2,1)];
lb = [0; 0; -inf; 0; 0]; ub = inf*ones(5,1);
x = simplex(A,b,p,lb,ub)


