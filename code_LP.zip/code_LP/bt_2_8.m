load ex5-2-8
B = [2 5];
N = [-1,-3,4,-6,-7,-8];
[x,B,N] = rsmbdd(A,b,p,lb,ub,B,N)


